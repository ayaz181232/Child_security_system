import React  from "react";
import {View,Text} from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import wellcomescreen from "./ayazscreen/wellcomescreen";
import Loginscreen from "./ayazscreen/Loginscreen";
import signup from "./ayazscreen/signup";
import drawer from "./ayazscreen/drawer";
import Overview from "./ayazscreen/Overview";
import Fense from "./ayazscreen/Fense";
import calllog from "./ayazscreen/calllog";
import smslog from "./ayazscreen/smslog";
import wifiusage from "./ayazscreen/wifiusage";
const Stack = createNativeStackNavigator();
 export default function app(){
     return(
        <NavigationContainer>
        <Stack.Navigator>
          <Stack.Screen 
          name="Loginscreen" 
          component={Loginscreen}
          options={{headerShown:false}}
          />
          <Stack.Screen 
          name="signup" 
          component={signup}
          options={{headerShown:false}}
          />
           <Stack.Screen 
          name="drawer" 
          component={drawer}
          options={{
            headerShown:false,
            headerStyle: {backgroundColor:'green'}
          }}
          />
          <Stack.Screen 
          name="Overview" 
          component={Overview}
          />
          <Stack.Screen 
          name="Fense" 
          component={Fense}
          />
          <Stack.Screen 
          name="calllog" 
          component={calllog}
          />
          <Stack.Screen 
          name="smslog" 
          component={smslog}
          />
          
        </Stack.Navigator>
      </NavigationContainer>
     )
 }