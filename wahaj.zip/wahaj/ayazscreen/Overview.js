import React from 'react';
import { View, Text,TouchableOpacity } from 'react-native';
import Icon from 'react-native-vector-icons/FontAwesome';

export default function Overview({navigation}) {
    return (
        <View style={{ flex: 1, backgroundColor: 'grey' }}>
            <View style={{ borderWidth: 1, flex: 1, margin: 20, backgroundColor: 'white', borderRadius: 20 }}>
                <View style={{ flexDirection: 'row', margin: 40,borderWidth:1}}>
                    <TouchableOpacity onPress={()=>navigation.navigate("Fense")}>
                    <View style={{ margin: 30,alignSelf:'center' }}>
                        <Icon name="map-marker" color='black' size={50} />
                        <Text style={{ color: 'black',marginRight:30 }}>
                            Fence
                        </Text>
                    </View>
                    </TouchableOpacity>
                    <TouchableOpacity onPress={()=>navigation.navigate("calllog")}>
                    <View style={{ margin: 30,alignSelf:'center' }}>
                        <Icon name="phone" color='black' size={40} />
                        <Text style={{ color: 'black' }}>
                            Calls Log
                        </Text>
                    </View>
                    </TouchableOpacity>
                </View>
                <View style={{ flexDirection: 'row', margin: 40,marginVertical:-10 ,borderWidth:1}}>
                <TouchableOpacity>
                    <View style={{ margin: 30 }}>
                        <Icon name="feed" color='black' size={40} style={{marginLeft:10}}/>
                        <Text style={{ color: 'black',textAlign:'center' }}>
                            Wife Usage
                        </Text>
                    </View>
                    </TouchableOpacity>
                    <TouchableOpacity onPress={()=>navigation.navigate("smslog")}>
                    <View style={{ margin: 30 }}>
                   
                        <Icon name="envelope" color='black' size={40} />
                        <Text style={{ color: 'black' }}>
                            SMS Log
                        </Text>
                    </View>
                    </TouchableOpacity>
                </View>
                <View style={{ flexDirection: 'row', margin: 40, justifyContent: 'space-between',borderWidth:1 }}>

                    <View style={{ margin: 30 }}>
                        <Icon name="plus-square" color='black' size={40} />
                        <Text style={{ color: 'black' }}>
                            Speed
                        </Text>
                    </View>
                    <View style={{ margin: 30 }}>
                        <Icon name="user-plus" color='black' size={40} />
                        <Text style={{ color: 'black' }}>
                            History
                        </Text>
                    </View>
                </View>

            </View>
        </View>
    )
}