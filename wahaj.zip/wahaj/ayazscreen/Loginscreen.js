import React, { useState } from "react";
import { View, Text, TextInput, TouchableOpacity } from 'react-native';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';

export default function Loginscreen({ navigation }) {
    const [user_email, setuser_email] = React.useState('');
    const [user_password, setuser_password] = React.useState('');
    const Logincheck = async () => {
        fetch('http://192.168.10.7/cssystem/api/Users/Login', {
            method: 'POST',
            headers: {
                Accept: 'application/json',
                'content-Type': 'application/json',
            },
            body: JSON.stringify({
                user_email: user_email,
                user_password: user_password,
            }),
        })
            .then(response => response.json())
            .then(responseJson => {
                console.log(responseJson)
                console.log(responseJson.user_Email)
                //console.log(responseJson.user_id)
                global.user_id=responseJson.user_id
                if (responseJson.user_Email == user_email && responseJson.user_password==user_password) {
                    navigation.navigate("drawer",)
                }
                else{
                    Window.alert("signup first")
                }
            })
    }
    return (
        <View style={{ justifyContent: 'center', flex: 1, backgroundColor: 'white', }}>
            <View >
                <Icon name="human-male-female-child" size={70} color="blue" style={{ marginLeft: 170 }} />
            </View>
            <Text style={{ color: 'black', textAlign: 'center', fontWeight: 'bold', fontSize: 40 }}> Login </Text>
            <TextInput
                onChangeText={user_email => setuser_email(user_email)}
                placeholder="Enter E-mail"
                placeholderTextColor={'black'}

                style={{ color: 'black', borderWidth: 2, borderColor: 'black', borderRadius: 30, padding: 12, borderLeftWidth: 0, borderRightWidth: 0, borderTopWidth: 0, width: 400, marginLeft: 10,paddingLeft: 20, fontSize: 20 }}
            />
            <TextInput
                onChangeText={user_password => setuser_password(user_password)}
                placeholder="Enter password"
                placeholderTextColor={'black'}
                style={{ color: 'black', borderWidth: 2, borderColor: 'black', borderRadius: 30, padding: 15, borderLeftWidth: 0, borderRightWidth: 0, borderTopWidth: 0, width: 400, marginLeft: 10, paddingLeft: 20, fontSize: 20 }}
            />
            <TouchableOpacity
                onPress={() => Logincheck()}
            >
                <Text style={{ borderWidth: 2, borderColor: 'white',backgroundColor:'blue', borderRadius: 30, marginVertical: 25, color: 'white', textAlign: 'center', width: 150, marginLeft: 130, padding: 10, fontWeight: 'bold', fontSize: 20 }}>Login</Text>
            </TouchableOpacity>
            <View style={{ flexDirection: 'row', justifyContent: 'center' }}>
                <Text style={{ color: 'black', fontSize: 15, fontWeight: "bold" }}>Don't have an account ? Click here !</Text>
                <TouchableOpacity
                    onPress={() => navigation.navigate("signup")}
                ><Text style={{ color: 'blue', textDecorationLine: 'underline', marginLeft: 5, fontSize: 15, fontWeight: "bold" }}>Sign up</Text></TouchableOpacity>
            </View>
        </View>
    )
}