import React, { useEffect, useState } from 'react';
import { View, Text } from 'react-native';
import { FlatList, TouchableOpacity } from 'react-native-gesture-handler';


export default function Dashboard({navigation}) {
  const [data, setdata] = useState()
  useEffect(() => {
    fetch('http://192.168.10.7/cssystem/api/Users/child', {
      method: 'GET',
      headers: {
        Accept: 'application/json',
        'content-Type': 'application/json',
      },
    })
      .then(response => response.json())
      .then(responseJson => {
        console.log(responseJson)
        setdata(responseJson)
      })
  },
    [],
  );
  return (
    <View style={{ backgroundColor: 'grey', flex: 1 }}>
      <FlatList
        data={data}
        keyExtractor={(item, index) => index.toString()}
        renderItem={({ item }) => (

          <TouchableOpacity
          onPress={()=>navigation.navigate("Overview")}
          >
            <View>
            <View style={{ flexDirection: 'row', margin: 10 }}>
              <View >
                <Text style={{ borderWidth: 1, borderRadius: 40, padding: 20, backgroundColor: 'white', color: 'black', fontWeight: 'bold' }}>{item.user_name[0]}</Text>
              </View>
              <Text style={{ color: 'black', margin: 5, fontWeight: 'bold' }}>{item.user_name}</Text>
              <View style={{ borderWidth: 1 }}>
              </View>
              <View style={{ flexDirection: 'column', margin: 10 }}>
                <Text style={{ fontWeight: 'bold' }}>Email:{item.user_Email}</Text>
                <Text style={{ fontWeight: 'bold' }}>Password:{item.user_password}</Text>
              </View>

            </View>
            <View style={{ borderWidth: 1 }}></View>
          </View>
          </TouchableOpacity>
        )}
      />
    </View>
  );
}