import React from 'react';
import {View,Text,TouchableOpacity} from 'react-native';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
export default function wellcomescreen({navigation}){
    return(
        <View style={{backgroundColor:'white',justifyContent:'center',flex:1}}>
            <View >
            <Icon name="human-male-female-child" size={70} color="blue" style={{marginLeft:170}} />
            </View>
            <Text style={{color:'black',textAlign:'center',fontWeight:'bold',}}>Child Security System</Text>
            <Text style={{color:'black',textAlign:'center',fontWeight:'bold',fontSize: 30}}>Wellcome To</Text>
            <Text style={{color:'black',textAlign:'center',fontWeight:'bold',fontSize: 30}}>Child Security</Text>
            <Text style={{color:'black',textAlign:'center',fontWeight:'bold',fontSize: 30}}>System</Text>
            <TouchableOpacity
            onPress={()=>navigation.navigate("Loginscreen")}
            >
                <Text style={{borderWidth:2,borderColor:'black',backgroundColor:'blue',borderRadius:30,color:'white',textAlign:'center',marginTop:280,width:150,marginLeft:130,padding:10,fontWeight:'bold',}}>Get Started</Text>
            </TouchableOpacity>
        </View>
    )
}