import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity } from 'react-native';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
export default function signup({ navigation }) {
    const [fullname, setfullname] = useState("");
    const [email, setemail] = useState("");
    const [password, setpassword] = useState("");
    const [phone, setphone] = useState("");
    const signup = async () => {
        fetch('http://192.168.10.7/cssystem/api/Users/Addusers', {
            method: 'POST',
            headers: {
                Accept: 'application/json',
                'content-Type': 'application/json',
            },
            body: JSON.stringify({
                user_name: fullname,
                user_Email: email,
                user_password: password,
                user_phone: phone,
                role:"Parent"
            }),
        })
            .then(response => response.json())
            .then(responseJson => {
                //console.log(responseJson)
                window.alert("sigup complete")
            })
    }
    return (
        <View style={{ justifyContent: 'center', flex: 1, backgroundColor: 'white', color: 'white' }}>
            <View >
                <Icon name="human-male-female-child" size={70} color="blue" style={{ marginLeft: 170 }} />
            </View>
            <Text style={{ color: 'black', textAlign: 'center', fontWeight: 'bold', fontSize: 30 }}> Sign Up </Text>
            <TextInput
                onChangeText={fullname => setfullname(fullname)}
                placeholder="Enter your full Name"
                placeholderTextColor={'black'}
                style={{ color: 'black', borderWidth: 2, borderColor: 'black', borderRadius: 30, padding: 15, borderLeftWidth: 0, borderRightWidth: 0, borderTopWidth: 0, width: 400, marginLeft: 10, paddingLeft: 20, fontSize: 20 }}
            />
            <TextInput
                onChangeText={email => setemail(email)}
                placeholder="Enter E-mail"
                placeholderTextColor={'black'}
                style={{ color: 'black', borderWidth: 2, borderColor: 'black', borderRadius: 30, padding: 15, borderLeftWidth: 0, borderRightWidth: 0, borderTopWidth: 0, width: 400, marginLeft: 10, paddingLeft: 20, fontSize: 20 }}
            />
             <TextInput
                onChangeText={phone => setphone(phone)}
                placeholder="Enter Phone No"
                placeholderTextColor={'black'}
                style={{ color: 'black', borderWidth: 2, borderColor: 'black', borderRadius: 30, padding: 15, borderLeftWidth: 0, borderRightWidth: 0, borderTopWidth: 0, width: 400, marginLeft: 10, paddingLeft: 20, fontSize: 20 }}
            />
            <TextInput
                onChangeText={password => setpassword(password)}
                placeholder="Enter password"
                placeholderTextColor={'black'}
                style={{ color: 'black', borderWidth: 2, borderColor: 'black', borderRadius: 30, padding: 15, borderLeftWidth: 0, borderRightWidth: 0, borderTopWidth: 0, width: 400, marginLeft: 10, paddingLeft: 20, fontSize: 20 }}
            />
            <TouchableOpacity
                // onPress={()=>Signup()}
                onPress={() => signup()}
            >
                <Text style={{ borderWidth: 2, borderColor: 'black',backgroundColor: 'blue', borderRadius: 30, marginVertical: 25, color: 'white', textAlign: 'center', width: 150, marginLeft: 130, padding: 10, fontWeight: 'bold', fontSize: 20 }}>Sign Up</Text>
            </TouchableOpacity>
            <View style={{ flexDirection: 'row', justifyContent: 'center' }}>
                <Text style={{ color: 'black', fontSize: 15, fontWeight: "bold" }}>Already have an account ? Click here to !</Text>
                <TouchableOpacity
                    onPress={() => navigation.navigate("Loginscreen")}
                ><Text style={{ color: 'blue', textDecorationLine: 'underline', marginLeft: 5, fontSize: 15, fontWeight: "bold" }}>Login</Text></TouchableOpacity>
            </View>


        </View>
    )
}