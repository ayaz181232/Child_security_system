import React,{useState} from 'react';
import { View, Text, TextInput, TouchableOpacity } from 'react-native';
import { blue } from 'react-native-reanimated/src/reanimated2/Colors';
export default function Addchild() {
    const [user_email, setuser_email] = React.useState('');
    const [user_name, setuser_name] = React.useState('');
    const [user_phone, setuser_phone] = React.useState('');
    const [user_password, setuser_password] = React.useState('');
    const Addchild=async()=>{
        fetch('http://192.168.10.7/cssystem/api/Users/Addusers', {
            method: 'POST',
            headers: {
                Accept: 'application/json',
                'content-Type': 'application/json',
            },
            body: JSON.stringify({
                user_name: user_name,
                user_Email: user_email,
                user_password: user_password,
                role:"Child"
            }),
        })
            .then(response => response.json())
            .then(responseJson => {
                //console.log(responseJson)
                window.alert("Child is added")
            })
    }
    return (
        <View style={{ flex: 1, backgroundColor: 'white', color: 'blue' }}>
            <Text style={{ color: 'blue', textAlign: 'center', fontWeight: 'bold', fontSize: 20 }}>Add child</Text>
            <TextInput
                onChangeText={user_name => setuser_name(user_name)}
                placeholder='Child Name'
                placeholderTextColor={'black'}
                style={{ color: 'black', borderWidth: 2, borderColor: 'black', borderRadius: 30, padding: 15, borderLeftWidth: 0, borderRightWidth: 0, borderTopWidth: 0, width: 400, marginLeft: 10, paddingLeft: 20, fontSize: 20 }}
            />
            <TextInput
                onChangeText={user_phone => setuser_phone(user_phone)}
                placeholder='phone Number'
                placeholderTextColor={'black'}
                keyboardType='number-pad'
                style={{ color: 'black', borderWidth: 2, borderColor: 'black', borderRadius: 30, padding: 15, borderLeftWidth: 0, borderRightWidth: 0, borderTopWidth: 0, width: 400, marginLeft: 10, paddingLeft: 20, fontSize: 20 }}
            />
            <TextInput
                onChangeText={user_email => setuser_email(user_email)}
                placeholder='child Email'
                placeholderTextColor={'black'}
                style={{ color: 'black', borderWidth: 2, borderColor: 'black', borderRadius: 30, padding: 15, borderLeftWidth: 0, borderRightWidth: 0, borderTopWidth: 0, width: 400, marginLeft: 10, paddingLeft: 20, fontSize: 20 }}
            />
            <TextInput
                onChangeText={user_password => setuser_password(user_password)}
                placeholder='Password'
                placeholderTextColor={'black'}
                style={{ color: 'black', borderWidth: 2, borderColor: 'black', borderRadius: 30, padding: 15, borderLeftWidth: 0, borderRightWidth: 0, borderTopWidth: 0, width: 400, marginLeft: 10, paddingLeft: 20, fontSize: 20 }}
            />
            <TouchableOpacity 
            onPress={()=>Addchild()}
            >
                <Text style={{ borderWidth: 3, borderColor: 'black', color: 'white',backgroundColor: 'blue', borderRadius: 20, marginLeft: 280, padding: 10, marginTop: 30, width: 80, textAlign: 'center' }}>Add</Text>
            </TouchableOpacity>
        </View>

    )
}