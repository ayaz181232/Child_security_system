import React, { useState, useEffect } from 'react';
import { StyleSheet, Text } from 'react-native';
import MapView, { Marker, Polygon, Polyline } from 'react-native-maps';
import Geolocation from '@react-native-community/geolocation';
const Fense = () => {
  const [position, setPosition] = useState({
    latitude: 33.6023456,
    longitude: 73.0920521,
    latitudeDelta: 0.001,
    longitudeDelta: 0.001,
  });

  const [coordinates] = React.useState([
    {
      latitude: 33.59722574776755,
      longitude: 73.0786135420203,
    },
    {
      latitude: 33.610147887281954,
      longitude: 73.08595910668373,
    },
    {
      latitude: 33.6043171773996,
      longitude:73.09823993593454,
    },
    {
      latitude: 33.59722574776755,
      longitude: 73.0786135420203,
    },
  ]);
  useEffect(() => {
    Geolocation.getCurrentPosition((pos) => {
      const crd = pos.coords;
      console.log(crd)
      setPosition({
        latitude: crd.latitude,
        longitude: crd.longitude,
        latitudeDelta: 0.0421,
        longitudeDelta: 0.0421,
      });
      console.log(crd.latitude)
      console.log(crd.longitude)
    }).catch((err) => {
      console.log(err);
    });
  }, []);
  const onMapPress = (e) => {
    // alert("coordinates:" + JSON.stringify(e.nativeEvent.coordinate))
    setPosition({
      ...position,
      latitude: e.nativeEvent.coordinate.latitude,
      longitude: e.nativeEvent.coordinate.longitude,

    })
    lat = position.latitude;
    console.log(position.latitude)
    lon = position.longitude;
    console.log(position.longitude)


  }
  return (
    <MapView
      onPress={(e) => onMapPress(e)}
      style={styles.map}
      initialRegion={position}
      showsUserLocation={true}
      showsMyLocationButton={true}
      followsUserLocation={true}
      showsCompass={true}
      scrollEnabled={true}
      zoomEnabled={true}
      pitchEnabled={true}
      rotateEnabled={true}>
      <Polyline
        coordinates={coordinates}
        strokeColor="#000"
        strokeColors={['#7F0000']}
        strokeWidth={3}
      />
      <Marker
        title='Yor are here'
        //  description='This is a description'
        coordinate={position}

      />

    </MapView>
  );
};

const styles = StyleSheet.create({
  map: {
    ...StyleSheet.absoluteFillObject,
  },
});

export default Fense;