import React from 'react';
import {View,Text} from 'react-native';
import { createDrawerNavigator } from '@react-navigation/drawer';
import Dashboard from './Dashboard';
import Addchild from './Addchild';
const Drawer = createDrawerNavigator();
export default function drawer({navigation}){
    return(
        <Drawer.Navigator>
      <Drawer.Screen 
      name="Child List"
       component={Dashboard}
       options={{
        headerTitle:'Child List' ,  
        headerStyle:{
           backgroundColor:'blue',
       }}}
       />
        <Drawer.Screen 
      name="Addchild"
       component={Addchild}
       options={{headerStyle:{
           backgroundColor:'blue',
       }}}
       />
    </Drawer.Navigator>
    )
}