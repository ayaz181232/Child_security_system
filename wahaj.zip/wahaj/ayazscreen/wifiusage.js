// import React from 'react';
// import { View, Text } from 'react-native';
// import { PermissionsAndroid } from 'react-native';
// import WifiManager from "react-native-wifi-reborn";
// export default function wifiusage() {
//     WifiManager.connectToProtectedSSID().then(
//         () => {
//           console.log("Connected successfully!");
//         },
//         () => {
//           console.log("Connection failed!");
//         }
//       );
      
//       WifiManager.getCurrentWifiSSID().then(
//         ssid => {
//           console.log("Your current connected wifi SSID is " + ssid);
//         },
//         () => {
//           console.log("Cannot get current SSID!");
//         }
//       );
//     const granted = PermissionsAndroid.request(
//         PermissionsAndroid.PERMISSIONS.ACCESS_FINE_LOCATION,
//         {
//             title: 'Location permission is required for WiFi connections',
//             message:
//                 'This app needs location permission as this is required  ' +
//                 'to scan for wifi networks.',
//             buttonNegative: 'DENY',
//             buttonPositive: 'ALLOW',
//         },
//     );
//     if (granted === PermissionsAndroid.RESULTS.GRANTED) {
//         // You can now use react-native-wifi-reborn
//     } else {
//         // Permission denied
//     }
//     return (
//         <View>
//             <Text>sdfjn</Text>
//         </View>
//     )
// }
